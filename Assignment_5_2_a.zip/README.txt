-----------------------Audio-Coprossesor-------------------------

SDU S�nderborg- MsSc. in Enginnering, Mechatronics
Author: Barne Carstensen

This is the final assignment for HSCOD

please use a different terminal than that used by SDK. I used putty and it worked fine.